// ===== PROFILE =====
const PROFILE = { name: "Rihamam", role: "Staff" };

// ===== ELEMENTS =====
const $ = (id) => document.getElementById(id);

const els = {
  avatar: $("avatar"),
  profileName: $("profileName"),
  profileRole: $("profileRole"),

  todayMain: $("todayMain"),
  todaySub: $("todaySub"),
  clock: $("clock"),

  taskInput: $("taskInput"),
  priority: $("priority"),
  taskDate: $("taskDate"),
  submitBtn: $("submitBtn"),
  deleteAllBtn: $("deleteAllBtn"),
  

  filterDate: $("filterDate"),
  filterTodayBtn: $("filterTodayBtn"),
  clearFilterBtn: $("clearFilterBtn"),

  stats: $("stats"),
  todoList: $("todoList"),
  doneList: $("doneList"),
  todoCount: $("todoCount"),
  doneCount: $("doneCount"),
  todoEmpty: $("todoEmpty"),
  doneEmpty: $("doneEmpty"),
  
};

els.priority.addEventListener("change", () => {
  if (els.priority.value) {
    els.priority.classList.add("valid");
  } else {
    els.priority.classList.remove("valid");
  }
});

// ===== STORAGE =====
const STORAGE_KEY = "todo_bootcamp_v3";
let tasks = loadTasks();
let activeDateFilter = ""; // YYYY-MM-DD or ""

initProfile();
initTime();
initDefaultDates();
render();

// ===== EVENTS =====
els.submitBtn.addEventListener("click", addTask);
els.deleteAllBtn.addEventListener("click", deleteAll);

els.filterDate.addEventListener("change", () => {
  activeDateFilter = els.filterDate.value || "";
  render();
});

els.filterTodayBtn.addEventListener("click", () => {
  activeDateFilter = toISODate(new Date());
  els.filterDate.value = activeDateFilter;
  render();
});

els.clearFilterBtn.addEventListener("click", () => {
  activeDateFilter = "";
  els.filterDate.value = "";
  render();
});

// Ctrl+Enter dari textarea
els.taskInput.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") addTask();
});

// ===== FUNCTIONS =====
function initProfile() {
  els.profileName.textContent = PROFILE.name;
  els.profileRole.textContent = PROFILE.role;

  const initials = PROFILE.name.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase()).join("");
  els.avatar.textContent = initials || "U";
}

function initTime() {
  updateTimeUI();
  setInterval(updateTimeUI, 1000 * 15);
}

function initDefaultDates() {
  // default due date = hari ini
  const todayISO = toISODate(new Date());
  els.taskDate.value = todayISO;

  // default filter kosong (tampil semua), tapi tombol "Hari Ini" ada
}

function updateTimeUI() {
  const now = new Date();
  els.todayMain.textContent = now.toLocaleDateString("id-ID", { weekday: "long" });
  els.todaySub.textContent = now.toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
  els.clock.textContent = now.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function toISODate(d) {
  // YYYY-MM-DD local
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function parseISODate(iso) {
  // interpret as local date
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function formatDayAndDate(iso) {
  const d = parseISODate(iso);
  const day = d.toLocaleDateString("id-ID", { weekday: "long" });
  const dateStr = d.toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
  return { day, dateStr };
}

function loadTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function addTask() {
  const text = els.taskInput.value.trim();
  if (!text) {
    alert("Tugas tidak boleh kosong.");
    return;
  }

  const dueISO = els.taskDate.value || toISODate(new Date());
  const { day, dateStr } = formatDayAndDate(dueISO);

  const task = {
    id: uid(),
    text,
    priority: els.priority.value, // low|medium|high
    done: false,
    dueISO,     // untuk "hari tertentu"
    day,        // untuk ditampilkan
    dateStr,    // untuk ditampilkan
    createdAt: new Date().toISOString(),
  };

  tasks.unshift(task);
  saveTasks();

  els.taskInput.value = "";
  els.taskInput.focus();

  els.priority.value = "";
  els.priority.classList.remove("valid");
  render();
}

function deleteAll() {
  const ok = confirm("Yakin mau hapus SEMUA To Do & Done?");
  if (!ok) return;
  tasks = [];
  saveTasks();
  render();
}

function toggleDone(id) {
  tasks = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
  saveTasks();
  render();
}

function deleteOne(id) {
  tasks = tasks.filter(t => t.id !== id);
  saveTasks();
  render();
}

function isOverdue(task) {
  if (task.done) return false;
  const today = parseISODate(toISODate(new Date()));
  const due = parseISODate(task.dueISO);
  return due < today;
}

function filteredTasks() {
  if (!activeDateFilter) return tasks;
  return tasks.filter(t => t.dueISO === activeDateFilter);
}

function render() {
  const list = filteredTasks();
  const todo = list.filter(t => !t.done);
  const done = list.filter(t => t.done);

  els.todoList.innerHTML = "";
  els.doneList.innerHTML = "";

  els.todoEmpty.style.display = todo.length ? "none" : "block";
  els.doneEmpty.style.display = done.length ? "none" : "block";

  todo.forEach(t => els.todoList.appendChild(renderItem(t, "todo")));
  done.forEach(t => els.doneList.appendChild(renderItem(t, "done")));

  // counts berdasarkan filter
  els.todoCount.textContent = `${todo.length} item`;
  els.doneCount.textContent = `${done.length} item`;

  // stats total global (biar jelas)
  const total = tasks.length;
  const totalDone = tasks.filter(t => t.done).length;
  const totalActive = total - totalDone;
  els.stats.textContent = `${total} tugas • ${totalActive} aktif • ${totalDone} selesai`;
}

function renderItem(task, type) {
  const li = document.createElement("li");
  li.className = "item";

  // status (checkbox)
  const status = document.createElement("div");
  status.className = "chkWrap";

  const cb = document.createElement("input");
  cb.type = "checkbox";
  cb.className = "chk";
  cb.checked = task.done;

  cb.addEventListener("change", () => toggleDone(task.id));

  const stLabel = document.createElement("div");
  stLabel.textContent = task.done ? "Done" : "To Do";

  status.appendChild(cb);
  status.appendChild(stLabel);

  // main content
  const main = document.createElement("div");

  const p = document.createElement("p");
  p.className = "taskText" + (task.done ? " done" : "");
  p.textContent = task.text;

  const meta = document.createElement("div");
  meta.className = "meta";

  const tagPriority = document.createElement("span");
  tagPriority.className = `tag ${task.priority}`;
  tagPriority.textContent = `Priority: ${cap(task.priority)}`;

  const tagDate = document.createElement("span");
  tagDate.className = "tag";
  tagDate.textContent = `${task.day}, ${task.dateStr}`;

  meta.appendChild(tagPriority);
  meta.appendChild(tagDate);

  // Bonus overdue
  if (isOverdue(task)) {
    const tagOver = document.createElement("span");
    tagOver.className = "tag overdue";
    tagOver.textContent = "Overdue/Late";
    meta.appendChild(tagOver);
  }

  main.appendChild(p);
  main.appendChild(meta);

  // actions
  const actions = document.createElement("div");
  actions.className = "actions";

  const del = document.createElement("button");
  del.className = "btnSmall danger";
  del.textContent = "Delete";
  del.addEventListener("click", () => deleteOne(task.id));

  actions.appendChild(del);

  li.appendChild(status);
  li.appendChild(main);
  li.appendChild(actions);

  return li;
}

function cap(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
